import axios from 'axios'

export const getTabList = () => axios.get('/parameter/tabsList') 