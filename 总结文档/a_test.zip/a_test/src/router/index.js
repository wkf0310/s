import Vue from 'vue'
import VueRouter from 'vue-router'


Vue.use(VueRouter)

/**
 * 学员: /students
 * 讲师: /teacher
 * 助教: /assistant 
 * 基础表格: /tableList
 * tab选项卡: /tab
 */

const routes = [
  {
    path: '/',
    redirect: '/students'
  },
  {
     path: '/',
     component: () => import('../components/SideBar/Sidebar.vue'),
     meta: {
      title: '公共部分',
     },
     children: [
      {
        path: '/students',
        name: 'students',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import(/* webpackChunkName: "about" */ '../views/Students.vue')
      },
      {
        path: '/teacher',
        name: 'teacher',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import(/* webpackChunkName: "about" */ '../views/Teacher.vue')
      },
      {
        path: '/assistant',
        name: 'assistant',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import(/* webpackChunkName: "about" */ '../views/Assiter.vue')
      },
      {
        path: '/assistant',
        name: 'assistant',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import(/* webpackChunkName: "about" */ '../views/Assiter.vue')
      },
      {
        path: '/tableList',
        name: 'tableList',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import(/* webpackChunkName: "about" */ '../views/TableList.vue')
      },
      {
        path: '/tab',
        name: 'tab',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import(/* webpackChunkName: "about" */ '../views/TabCard.vue')
      }
     ],
  },
  
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
