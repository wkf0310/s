

const getters = {
    tabLists: state => state.tabLists,
    routeList: state => state.routeList
}

export default getters