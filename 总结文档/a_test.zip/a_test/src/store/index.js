import Vue from 'vue'
import Vuex from 'vuex'
import tabLists from './modules/tabLists'
import routeList from './modules/routeList'
import getters from './getters'
import persistedState from 'vuex-persistedstate'
Vue.use(Vuex)

export default new Vuex.Store({
  plugins: [persistedState({storage: window.sessionStorage})],
  modules: {
    tabLists,
    routeList
  },
  getters
})
