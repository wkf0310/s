import {getTabList} from '../../../api/api'

//state
const state = {
    /**未读列表 */
    unReadList: [],
    /**已读列表 */
    readList: [],
    /** 回收站 */
    recycleBinList: [],
    /**所有列表信息 */
    allList: {},
    /**点击未读列表的tab */
    unReadVisible: true,
    /**点击已读列表的tab */
    readVisible: false,
    /**点击回收站列表的tab */
    recycleBinVisible: false,
}


//设置mutations
const mutations = {
    // 保存所有列表信息
    saveAllList: (state, played) => {
        const {unread,read,recycle} = played   
        state.allList = played
        state.unReadList = unread
        state.readList = read
        state.recycleBinList = recycle
    },
    //切换tab栏,修改tab信息 
    updateUnRead: (state,played) => {
        console.log(played,'played');
        state.unReadVisible = played === "unRead" 
        state.readVisible = played === "read" 
        state.recycleBinVisible = played === "recycleBin" 
    },
    //标记为已读,删除数据,并且添加在已读中添加数据
    updateReadList: (state,played) => {
        state.unReadList =  played.resultList;
        state.readList.push(played.delInfo)
    },
    //删除当前信息,删除数据,并且添加在回收站数据中
    delReadList: (state,played) => {
        state.readList =  played.resultList;
        state.recycleBinList.push(played.delInfo)
    }
}

//设置actions
const  actions = {
   getTabList: (context,played) => {
    getTabList().then(res => {
        context.commit('saveAllList',res.data.data.data)
    })
   }
}



export default {
    namespaced: true,
    state,
    actions,
    mutations
}