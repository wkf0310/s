
//state
const state = {
    /**点击过路由的集合 */
    routesList: [],
}


//设置mutations
const mutations = {
    // 保存所有列表信息
    addRouteList: (state, played) => {
        state.routesList = state.routesList.filter(item => item !== played)
        state.routesList.push(played)
    },
    // 点击tag列表删除其中一条信息
    delRouteList: (state,played) => {
        state.routesList =  state.routesList.filter(item => item !== played)
    },
    //清空所有
    clearAllInfo: (state) => {
        state.routesList = []
    },
    /**去掉其中的一个数据 */
    spliceOther: (state,played) => {
        console.log(played);
        state.routesList =  state.routesList.filter(item => item.path == played)
    }
   
}

//设置actions
const  actions = {
  
}


export default {
    namespaced: true,
    state,
    actions,
    mutations
}