<template>
  <div>
    <el-container>
      <el-header>
        <el-menu
          :default-active="'1'"
          class="aaa el-menu-demo"
          mode="horizontal"
          background-color="#545c64"
          text-color="#fff"
          active-text-color="#ffd04b"
          style="paddingLeft: 200px"
        >
          <el-menu-item index="1"><i class="el-icon-user"></i>用户</el-menu-item>
          <el-menu-item index="1"><i class="el-icon-s-opportunity"></i>教学</el-menu-item>
          <el-menu-item index="1"><i class="el-icon-share"></i>题库</el-menu-item>
          <el-menu-item index="1"><i class="el-icon-s-grid"></i>运营</el-menu-item>
          <el-menu-item index="1"><i class="el-icon-s-data"></i>营销</el-menu-item>
          <el-menu-item index="1"><i class="el-icon-s-flag"></i>商品</el-menu-item>
          <el-menu-item index="1"><i class="el-icon-s-comment"></i>财务</el-menu-item>
          <el-menu-item index="1"><i class="el-icon-menu"></i>统计</el-menu-item>
          <el-menu-item index="1"><i class="el-icon-s-open"></i>系统</el-menu-item>
          <el-menu-item index="1"> <i class="el-icon-rank"></i></el-menu-item>
        </el-menu>
 
       
      </el-header>
      <el-container>
        <el-aside>
          <el-menu
            default-active="/students"
            class="el-menu-vertical-demo"
            background-color="#545c64"
            text-color="#fff"
            @select="handleSelect"
            active-text-color="#ffd04b"
            unique-opened
            router
          >
            <template v-for="item in items">
              <el-menu-item :index="item.path" :key="item.id">
              <i class="el-icon-menu"></i>
              <span slot="title">{{item.title}}</span>
            </el-menu-item>
          </template>
            <!-- <el-menu-item index="/students">
              <i class="el-icon-document"></i>
              <span slot="title">学生管理</span>
            </el-menu-item>
            <el-menu-item index="/teacher">
              <i class="el-icon-document"></i>
              <span slot="title">教师管理</span>
            </el-menu-item>
            <el-menu-item index="/assistant">
              <i class="el-icon-setting"></i>
              <span slot="title">助教管理</span>
            </el-menu-item> -->
          </el-menu>
        </el-aside>
        <keep-alive>
          <el-main>
            <router-view></router-view>
          </el-main>
        </keep-alive>
      </el-container>
    </el-container>
  </div>
</template>
<script>
export default {
  name: "Sidebar",
  data() {
    return {
      items: [
        {
          id: 1,
          title: "学生管理",
          name: "students",
          path: "/students",
        },
        {
          id:2,
          title: "教师管理",
          name: "teacher",
          path: "/teacher",
        },
        {
          id:3,
          title: "助教管理",
          name: "assistant",
          path: "/assistant",
        },
         {
          id:4,
          title: "基础表格",
          name: "tableList",
          path: "/tableList",
        },
         {
          id:5,
          title: "tab选项卡",
          name: "tab",
          path: "/tab",
        },
      ],
    };
  },
  computed: {
    onRoutes() {
      console.log(this.$route.fullPath);
      return this.$route.fullPath;
    },
  },
  methods: {
    handleSelect(val) {
      this.items.forEach(item => {
        if(item.path === val) {
           this.$store.commit('routeList/addRouteList', item)
        }
      })
    }
  },
};
</script>
<style scoped lang="scss">
.el-header {
  background-color: #b3c0d1;
  color: #333;
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #d3dce6;
  color: #333;
  text-align: center;
  line-height: 200px;
  height: 100vh;
  width: 200px !important;
}

.el-main {
  //   background-color: #e9eef3;
  color: #333;
  //   text-align: center;
  //   line-height: 160px;
}

.el-header{
  padding: 0;
}
body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
.el-menu-vertical-demo{
  height: 100vh;
}
</style>
