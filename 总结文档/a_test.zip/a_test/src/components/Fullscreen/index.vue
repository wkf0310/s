<template>
    <div>
        <a role="button" @click="click">
            <svg-icon :icon-class="isFullscreen? 'exit-fullscreen' : 'fullscreen'"></svg-icon>
        </a>
    </div>
</template>
<script>
    import screenfull from 'screenfull'
    export default {
        name: 'FullScreen',
        data() {
            return {
                isFullscreen: false
            }
        }
    }
</script>
<style scoped lang="scss">

</style>