<template>
  <div>
    <header>学生管理</header>
    <content>
      <el-form
        ref="formInline"
        :inline="true"
        :model="formInline"
        class="demo-form-inline"
      >
        <el-form-item label="学员状态">
          <el-select
            v-model="formInline.status"
            placeholder="请选择"
            prop="status"
          >
            <el-option label="启用" :value="1" />
            <el-option label="禁用" :value="0" />
          </el-select>
        </el-form-item>
        <el-form-item label="学生名称" prop="name">
          <el-input
            v-model="formInline.name"
            placeholder="请输入学生关键字"
          ></el-input>
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input
            v-model="formInline.phone"
            placeholder="请输入手机号"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-button @click="onSubmit"
            ><i class="iconfont el-icon-search" />搜索</el-button
          >
          <el-button @click="resetForm('formInline')"
            ><i class="iconfont el-icon-magic-stick" />重置</el-button
          >
        </el-form-item>
        <el-form-item>
          <el-button type="primary">新增学员</el-button>
          <el-button type="primary">批量导入</el-button>
          <el-button type="primary">批量导出</el-button>
          <el-button type="primary">查看报表</el-button>
        </el-form-item>
      </el-form>
      <el-table
        border
        ref="multipleTable"
        :data="tableList"
        tooltip-effect="dark"
        style="width: 100%"
        :header-cell-style="{ 'text-align': 'center' }"
        :cell-style="{ 'text-align': 'center' }"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="nickname" label="学生姓名">
          <template slot-scope="scope">
            <img :src="scope.row.avatar" />{{ scope.row.nickname }}
          </template>
        </el-table-column>
        <el-table-column prop="mobile" label="手机号"> </el-table-column>
        <el-table-column prop="status" label="状态">
          <template slot-scope="scope">
            <el-tag v-if="scope.row.status === 1" type="success">启用</el-tag>
            <el-tag v-else type="danger">禁用</el-tag>
          </template> 
        </el-table-column>
        <el-table-column prop="created_at" label="创建时间">
          <template slot-scope="scope">
            <!-- {{formatUnixtimestamp(scope.row.created_at)}} -->
            {{ scope.row.created_at | moment }}
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="操作" width="240">
          <template slot-scope="scope">
            <el-button type="text" size="small">详情</el-button>
            <el-button type="text" size="small">编辑</el-button>
            <el-button type="text" size="small">{{
              scope.row.status === 0 ? "启用" : "禁用"
            }}</el-button>
            <el-button type="text" size="small">删除</el-button>
            <el-button type="text" size="small">重置密码</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        @size-change="(value) => (pageSize = value)"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="this.tableListCopy.length"
        class="pageSign"
      >
      </el-pagination>
    </content>
  </div>
</template>

<script>
import moment from "moment";
import axios from 'axios'
export default {
  data() {
    return {
      formInline: {
        /**启用1 禁用0 */
        status: "",
        /**学生姓名 */
        name: "",
        /**手机号 */
        phone: "",
      },
      data: [],
      /**列表信息 */
      //   tableList: [],
      tableListCopy: [],
      /**每页展示条数 */
      pageSizes: [1, 5, 7, 10, 20, 30],
      /**当前页数 */
      pageSize: 10,
      /**第几页 */
      pageNum: 1,
      /**当前页码 */
      currentPage: 1,
    };
  },
  computed: {
    tableList: {
      get: function () {
        let tableLists = [];
        if (this.currentPage === 1) {
          tableLists = this.tableListCopy.slice(0, this.pageSize);
        } else {
          tableLists = this.tableListCopy.slice(
            (this.currentPage - 1) * this.pageSize,
            this.currentPage * this.pageSize
          );
        }
        return tableLists;
      },
    },
  },
  filters: {
    /**时间过滤器 */
    moment: function (value) {
      if (value.length < 13) {
        return moment(value * 1000).format("YYYY-MM-DD HH:mm:ss");
      } else {
        return moment(value).format("YYYY-MM-DD HH:mm:ss");
      }
    },
  },
  created(){
    axios.get('/parameter/query').then(res => {
        console.log(res);
        if(res.data.status === 200) {
            console.log(res.data.data,'161');
            this.data = res.data.data.data
            this.tableListCopy = res.data.data.data
        }
    })
  },
  methods: {
    /**提交表单信息 */
    onSubmit() {
      let status = this.formInline.status;
      let name = this.formInline.name;
      let phone = this.formInline.phone;
      // 用switch case
      if (status || (status === 0 && name && phone)) {
        this.searchThree();
      } else if (status || (status === 0 && name && !phone)) {
        this.searchStatusAndName();
      } else if (status || (status === 0) && !name && phone) {
        this.searchStatusAndPhone();
      } else if (!status && name && phone && status !== 0) {
        this.searchNameAndPhone();
      } else if (!status && !name && phone && status !== 0) {
        this.searchPhone();
      } else if (!status && name && !phone && status !== 0) {
        this.searchName();
      } else if ((status || status === 0) && !name && !phone) {
        this.searchStatus();
      }
    },
    /**只有启用,  */
    searchStatus() {
      this.tableListCopy = data.filter(
        (item) => item.status === this.formInline.status
      );
    },
    /**只查询姓名 */
    searchName() {
      this.tableListCopy = data.filter(
        (item) => item.nickname.indexOf(this.formInline.name) > -1
      );
    },
    /**只查询手机号 */
    searchPhone() {
      this.tableListCopy = data.filter(
        (item) => item.mobile.indexOf(this.formInline.phone) > -1
      );
    },
    /**启用+姓名 */
    searchStatusAndName() {
      let result1 = data.filter(
        (item) => item.status === this.formInline.status
      );
      this.tableListCopy = result1.filter(
        (item) => item.nickname.indexOf(this.formInline.name) > -1
      );
    },
    /**启用+手机号 */
    searchStatusAndPhone() {
      let result1 = data.filter(
        (item) => item.status === this.formInline.status
      );
      this.tableListCopy = result1.filter(
        (item) => item.mobile.indexOf(this.formInline.phone) > -1
      );
    },
    /**姓名+手机号 */
    searchNameAndPhone() {
      let result1 = data.filter(
        (item) => item.nickname.indexOf(this.formInline.name) > -1
      );
      this.tableListCopy = result1.filter(
        (item) => item.mobile.indexOf(this.formInline.phone) > -1
      );
    },
    /**启用+手机号+姓名 */
    searchThree() {
      let result1 = data.filter(
        (item) => item.status === this.formInline.status
      );
      let result2 = result1.filter(
        (item) => item.nickname.indexOf(this.formInline.name) > -1
      );
      this.tableListCopy = result2.filter(
        (item) => item.mobile.indexOf(this.formInline.phone) > -1
      );
    },
    /**重置表单信息 */
    resetForm(formName) {
      this.$refs[formName].resetFields();
      this.formInline.status = "";
      this.tableListCopy = data;
    },
    /**把时间转换为时间戳 */
    formatUnixtimestamp(value) {
      // if(value) {
      //     if(value.length<13) {
      //         value = value * 1000
      //         return moment(value).format('YYYY-MM-DD HH:mm:ss')
      //     }
      // }
      //   var unixtimestamp = new Date(unixtimestamp * 1000);
      //   var year = 1900 + unixtimestamp.getYear();
      //   var month = "0" + (unixtimestamp.getMonth() + 1);
      //   var date = "0" + unixtimestamp.getDate();
      //   var hour = "0" + unixtimestamp.getHours();
      //   var minute = "0" + unixtimestamp.getMinutes();
      //   var second = "0" + unixtimestamp.getSeconds();
      //   return (
      //     year +
      //     "-" +
      //     month.substring(month.length - 2, month.length) +
      //     "-" +
      //     date.substring(date.length - 2, date.length) +
      //     " " +
      //     hour.substring(hour.length - 2, hour.length) +
      //     ":" +
      //     minute.substring(minute.length - 2, minute.length) +
      //     ":" +
      //     second.substring(second.length - 2, second.length)
      //   );
    },
    // /**pageSize 改变时会触发 */
    // handleSizeChange(value) {
    //     this.pageSize = value
    // }
    //
    /**当前页改变时候会 触发 */
    handleCurrentChange(value) {
      console.log(value);
      this.currentPage = value;
    },
  },
};
</script>

<style lang="scss" scoped>
header {
  text-align: left;
  border-bottom: 1px solid #ccc;
  padding: 0 0 20px 20px;
  margin-bottom: 20px;
}

content {
  text-align: left;

  .iconfont {
    font-size: 13px;
    margin-right: 10px;
  }

  img {
    width: 12%;
    vertical-align: middle;
    margin-right: 10px;
  }

  .pageSign{
    text-align: right;
    margin-top: 10px;
  }
}
</style>
