<template>
  <div>
    <el-dialog title="编辑" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="用户名" :label-width="formLabelWidth">
          <el-input v-model="form.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="地址" :label-width="formLabelWidth">
          <el-input v-model="form.address" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveForm"
          >确 定</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>
<script>
    export default {  
        data() {
            return {
                formLabelWidth: '120px',
                dialogFormVisible: false,
                form: {}
            }
        },
        methods:{
            init(rowValue) {
                console.log(rowValue,'init');
                this.dialogFormVisible = true
                this.form= rowValue
                // this.form.name = rowValue.name
                // this.form.address = rowValue.address
            },
            saveForm() {
                this.dialogFormVisible = false
                this.$emit('updateTableList', this.form)
            }
        }
    }

</script>
<style scoped lang="scss"></style>
