<template>
  <div>
    <ClickRouLink/>
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="未读消息" name="unRead" />
      <el-tab-pane label="已读消息" name="read" />
      <el-tab-pane label="回收站" name="recycleBin" />
      <el-table :data="tableList" :show-header="false">
        <el-table-column prop="title" label="信息" width="1000px">
        </el-table-column>
        <el-table-column prop="date" label="时间">
        </el-table-column>
        <el-table-column  label="操作"> 
            <template slot-scope="scope">
                <!-- 未读消息 -->
                <el-button v-if="unReadVisible" @click="updateRead(scope.row)">标为已读</el-button>
                <!-- 已读消息 -->
                <div v-if="readVisible">
                    <el-button type="danger" @click="delOneReadList(scope.row)">删除</el-button>
                    <el-button>还原未读</el-button>
                </div>
                <!-- 回收站 -->
                <el-button v-if="recycleBinVisible">还原</el-button>
            </template>
        </el-table-column>
      </el-table>
      <div class="bt">
           <!-- 已读消息 -->
       <el-button type="danger" v-if="readVisible">删除全部</el-button>
       <!-- 未读消息 -->
       <el-button type="primary" v-if="unReadVisible">全部标为已读</el-button>
       <!--  回收站-->
       <el-button type="danger" v-if="recycleBinVisible">清空回收站</el-button>
      </div>
    
    </el-tabs>
  </div>
</template>
<script>
import {mapActions,mapGetters,mapState,mapMutations} from 'vuex'
import ClickRouLink from './ClickRouLink'
export default {
  data() {
    return {
      tableList: [],
      activeName: 'unRead',
      readVisible: false,
      unReadVisible: true,
      recycleBinVisible: false
    };
  },
  components:{
    ClickRouLink
  },
  created() {
      this['tabLists/getTabList']()
      setTimeout(() => {
        this.updateTabList()
      }, 600)
  },
  computed:{
 
        // ...mapState({  //用mapState来获取collection.js里面的state的属性值
        //    unReadList:state => state.tabLists.unReadList,
        //    readList:state=>state.tabLists.readList,
        //    recycleBinList:state=>state.tabLists.recycleBinList

        //this.$store.state.tabLists

        // }),
         // 第三种
         // this.$store.getters.tabLists
         ...mapGetters(['tabLists'])
        
         //this.$store.dispatch('模块名/actions方法名', 具体值)
         //this.$store.commit('模块名/actions方法名', 具体值)
    },
  methods: {
      ...mapActions(["tabLists/getTabList"]),
      ...mapMutations("tabLists", [
        "updateUnRead" ,'updateReadList','delReadList'
      ]),
      /**点击tab切换列表信息 */
      handleClick(value) {
        this.updateUnRead(value._props.name)
        this.updateTabList()
      },
      /**重新修改赋值 */
      updateTabList() {
      const {unReadVisible, readVisible, unReadList,readList,recycleBinList,recycleBinVisible } = this.tabLists
        console.log(this.tabLists,' this.tabLists');
        this.tableList = unReadVisible ? unReadList : readVisible ?  readList : recycleBinList
        this.unReadVisible = unReadVisible
        this.readVisible = readVisible
        this.recycleBinVisible = recycleBinVisible
      },

      /**标记为已读,从未读中删除当前信息,并且添加到已读中 */
      updateRead(row) {
        // this.tableList = this.tableList.filter(item => item !== row)
        // this.updateReadList({unReadList:this.tableList, delInfo: row })
        this.disposeCommonList(row, this.updateReadList)
      },

      /**删除已读,从已读中删除当前信息,并且添加到回收站中 */
      delOneReadList(row) {
        // this.tableList = this.tableList.filter(item => item !== row)
        // console.log(this.tableList);
        // this.delReadList({readList: this.tableList, delInfo: row})
        this.disposeCommonList(row, this.delReadList)
      },

      /**公共方法抽离 */
      disposeCommonList(row, fn) {
        this.tableList = this.tableList.filter(item => item !== row)
        fn({resultList:this.tableList, delInfo: row })
      }
  },
};
</script>
<style scoped lang="scss">

.bt{
  text-align: left;
  margin-top: 20px;
  margin-left: 20px;
}
</style>
