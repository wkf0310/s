<template>
  <div class="clickRoute">
    <div>
      <el-tag
        :key="router.id"
        v-for="router in routeList"
        closable
        :disable-transitions="false"
        @close="handleClose(router)"
      >
        <router-link class="routerClass" :to="router">{{
          router.title
        }}</router-link>
      </el-tag>
    </div>

    <div>
      <el-dropdown v-if="routeList.length>0"  @command="handleClose">
        <el-button type="primary">
          标签选项<i class="el-icon-arrow-down el-icon--right"></i>
        </el-button>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="all">关闭所有</el-dropdown-item>
          <el-dropdown-item command="other">关闭其他</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
    //   routeList: [],
    };
  },
  created() {
  },
  computed:{
        routeList: {
            get: function(){
                return this.$store.state.routeList.routesList;
            }
        }
  },
  methods: {
    handleClose(router) {
      this.routeList.splice(this.routeList.indexOf(router), 1);
      this.$store.commit("routeList/delRouteList", router);
    },
    handleClose(command) {
        console.log(command);
        if(command === 'all') {
            this.$store.commit('routeList/clearAllInfo')
        } else {
            this.$store.commit('routeList/spliceOther', this.$route.fullPath)
        }
       
    }
  },
};
</script>
<style scoped lang="scss">
.el-tag {
  margin-right: 15px;
  text-align: left;
}
.clickRoute {
  margin-bottom: 20px;
  display: flex;
  justify-content: space-between;
}
.routerClass {
  margin: 10px;
}
</style>
