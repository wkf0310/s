<template>
  <!--基础表格 -->
  <div class="tablist">
    <ClickRouLink/>
    <div class="del">
      <el-button
        :disabled="this.ids.length === 0"
        type="primary"
        class="mr"
        @click="delHandle"
        ><i class="el-icon-delete" />删除选中</el-button
      >
      <el-select v-model="query.address" class="mr" placeholder="请选择地址">
        <el-option
          v-for="item in addressList"
          :label="item.label"
          :value="item.label"
          :key="item.id"
        ></el-option>
      </el-select>
      <el-input
        v-model="query.queryInput"
        placeholder="请输入要查询的地址"
        class="mr input"
        @input="handleInput"
      />
    </div>

    <el-table
      border
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      @selection-change="
        (val) => {
          this.ids = val.map((item) => item.id);
        }
      "
      :header-cell-style="{ 'text-align': 'center' }"
      :cell-style="{ 'text-align': 'center' }"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column prop="id" label="id" width="50" />
      <el-table-column prop="name" label="用户名" />
      <el-table-column prop="money" label="账户余额" />
      <el-table-column prop="thumb" label="头像(查看大图)">
        <template slot-scope="scope">
          <el-image
            style="width: 50px; height: 50px"
            :src="scope.row.thumb"
            :preview-src-list="[scope.row.thumb]"
          >
          </el-image>
        </template>
      </el-table-column>
      <el-table-column prop="address" label="地址" />
      <el-table-column prop="state" label="状态">
        <template slot-scope="scope">
          <el-tag type="success" v-if="scope.row.state === '成功'">成功</el-tag>
          <el-tag type="warning" v-else>失败</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="date" label="注册时间" />
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="text" @click="updateInfo(scope.row)"
            ><i class="el-icon-edit" />编辑</el-button
          >
          <el-button type="text" class="fontsize" @click="delOne(scope.row)"
            ><i class="fontsize el-icon-delete" />删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="pagination"
      :current-page="currentPage"
      :page-size="pageSize"
      layout="total, prev, pager, next"
      :total="total"
    >
    </el-pagination>
    <UpdateDialog
      v-if="updateVisible"
      ref="updateDialog"
      @updateTableList="updateTableList"
    />
  </div>
</template>
<script>
import UpdateDialog from "@/views/UpdateDialog";
import ClickRouLink from './ClickRouLink'
export default {
  data() {
    return {
      tableData: [],
      tableDataCopy: [],
      currentPage: 1,
      pageSize: 10,
      total: 0,
      /**下拉地址 */
      addressList: [],
      query: {
        address: "",
        queryInput: "",
      },
      /**删除数组id */
      ids: [],
      /**修改的显隐 */
      updateVisible: false,
    };
  },
  components: {
    UpdateDialog,
  },
  created() {
    this.getTableList();
    this.getAdressInfo();
  },
  methods: {
    /**获取列表信息 */
    getTableList() {
      this.$http.get("/parameter/tableList").then((res) => {
        const data = res.data.data;
        if (data.status === 200) {
          this.tableData = data.list;
          this.tableDataCopy = data.list;
          this.total = data.pageTotal;
        } else {
          this.$message.error("网络不好");
        }
      });
    },
    /**获取地址信息 */
    getAdressInfo() {
      this.$http.get("/parameter/address").then((res) => {
        const data = res.data.data;
        if (data.status === 200) {
          this.addressList = data.list;
        } else {
          this.$message.error("网络不好");
        }
      });
    },

    /**删除选中 */
    delHandle() {
      if (this.ids.length === 0) {
        this.$message.error("请至少选择一条要删除的数据");
      } else {
        this.delFn(this.ids)
      }
    },

    /**删除的公共方法 */
    delFn(ids) {
      let id = Array.isArray(ids) ? ids : [ids]
      this.$http.delete("/parameter/del", { ids:id }).then((res) => {
        if (res.status === 200) {
          this.$message.success("删除成功");
          this.tableData = this.tableDataCopy.filter(
            (item) => !id.includes(item.id)
          );
          this.total = this.total - this.tableDataCopy.length;
        } else {
          this.$message.error("网络信息有误");
        }
      });
    },

    /**查询input事件 */
    handleInput() {
      let inputValue = this.query.queryInput;
      console.log(inputValue);
      let tableList = [];
      if (!inputValue) {
        this.tableData = this.tableDataCopy;
      } else {
        this.tableDataCopy.forEach((item) => {
          if (
            item.address.indexOf(inputValue) > -1 &&
            item.address.indexOf(this.query.address) > -1
          ) {
            tableList.push(item);
          }
        });
        this.tableData = tableList;
       
      }
        this.total = this.tableData.length
    },

    /**修改 */
    updateInfo(rowValue) {
      this.updateVisible = true;
      this.$nextTick(() => {
        this.$refs.updateDialog.init(rowValue);
      });
    },

    /**修改过后修改列表数据 */
    updateTableList(value) {
      this.tableData.forEach((item) => {
        if (item.id === value.id) {
          item = value;
        }
      });
    },

    /**删除单行内容 */
    delOne(value) {
       this.$confirm('此操作将永久删除该数据, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
           this.delFn(value.id)
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
      }
  },
};
</script>
<style scoped lang="scss">
.tablist {
  text-align: left;
  .del {
    margin-bottom: 10px;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
  .pagination {
    margin-top: 10px;
    text-align: right;
  }
  .fontsize {
    color: red;
  }
  .input {
    width: 20%;
  }
  .mr {
    margin-right: 10px;
  }
}
</style>
