<template>
    <div>
        我是老师
    </div>
</template>
<script>
</script>
<style lang="scss" scoped>
</style>